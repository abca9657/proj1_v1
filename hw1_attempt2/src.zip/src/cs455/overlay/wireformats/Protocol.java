package cs455.overlay.wireformats;

// what should go here? 
public interface Protocol {
	public byte OVERLAY_NODE_SENDS_REGISTRATION = 2;
	/*public void REGISTRY_REPORTS_REGISTRATION_STATUS();
	
	static final byte OVERLAY_NODE_SENDS_DEREGISTRATION = 4;
	static final byte REGISTRY_REPORTS_DEREGISTRATION_STATUS = 5;
	
	static final byte REGISTRY_SENDS_NODE_MANIFEST = 6;
	static final byte NODE_REPORTS_OVERLAY_SETUP_STATUS = 7;
	
	static final byte REGISTRY_REQUESTS_TASK_INITIATE = 8;
	static final byte OVERLAY_NODE_SENDS_DATA = 9;
	static final byte OVERLAY_NODE_REPORTS_TASK_FINISHED = 10;
	
	static final byte REGISTRY_REQUESTS_TRAFFIC_SUMMARY = 11;
	static final byte OVERLAY_NODE_REPORTS_TRAFFIC_SUMMARY = 12;*/
	
}
