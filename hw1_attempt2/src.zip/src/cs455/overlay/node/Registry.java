package cs455.overlay.node;

//import java.awt.Event;
import cs455.overlay.transport.TCPServerThread;
import cs455.overlay.wireformats.Event;
import cs455.overlay.wireformats.Protocol;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import cs455.overlay.wireformats.EventFactory;

public class Registry implements Node {

	private final int portNumber;

	public static void main(String[] args) throws IOException {

		// create portnum for registry:
		if (args.length != 1) {
			System.err.println("Usage: java cs455.overlay.node.Registry <portnumber>");
			System.exit(1);
		}
		int portNum = Integer.parseInt(args[0]);
		EventFactory ef = new EventFactory(this);
		
		TCPServerThread newThread = new TCPServerThread(portNum);
		Thread startNewThread = new Thread(newThread);
		startNewThread.start();
				
		
		// Initialize the registry: 
		RegisterEntrys registryEntry = new RegisterEntrys();
		// you will add each messaging node to this list
		
		// Keep track of IDs: 
		//UsedRegIDs usedIDs = new UsedRegIDs();
		List<Integer> usedRegisterIDs = new ArrayList<Integer>();
		
		
		

	}
	
	
	//private void onEvent(byte eventAbby){
		
		
		/*
		if(eventAbby == OVERLAY_NODE_SENDS_REGISTRATION){
			//DO stuff
			//Call method to do stuff
			eventAbby.Dostuffwith(registry, other crap, )
		}
		*/
		
	//}

	// this is type Node
	public Registry(int portNumber) {
		this.portNumber = portNumber;
		
		/*
		try {
			EventFactory ef = new EventFactory(this);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	}


	@Override
	public void onEvent(byte msg) {
		// TODO Auto-generated method stub
		
	}

	/*
	 * This method creates a socket listener on the portNumber and waits for 
	 * connection requests, and accepts all requests and creates a new thread to 
	 * handle all new connections 
	 */


}
