package cs455.overlay.node;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import cs455.overlay.transport.TCPConnection;
import cs455.overlay.transport.TCPServerThread;
import cs455.overlay.wireformats.OVERLAY_NODE_SENDS_REGISTRATION;

public class MessagingNode {
	private final int regPortNum;

	public static void main(String[] args) throws InterruptedException, IOException {
		// parse input arguments from user: 
		if (args.length != 2) {
			System.err.println("Usage: java cs455.overlay.node.MessagingNode <RegistryHost> <RegistryPort>");
			System.exit(1);
		}
		String hostName = args[0];
		int regPortNum = Integer.parseInt(args[1]);
		
		TCPServerThread newTCPServerThread = new TCPServerThread(0);
		Thread startTCPServSock = new Thread(newTCPServerThread);
		startTCPServSock.start();
		
		
		OVERLAY_NODE_SENDS_REGISTRATION newRegistrationMsg = new OVERLAY_NODE_SENDS_REGISTRATION(newTCPServerThread.getMsgType(), newTCPServerThread.getLocalAddrLen(),
				newTCPServerThread.getLocalAddr(), newTCPServerThread.getLocalPortNum());
		
		Socket socket = new Socket(hostName, regPortNum);
		TCPConnection sendRegistryInfo = new TCPConnection(socket, newRegistrationMsg.getBytes());
				

	}
	
	
	




	public MessagingNode(int regPortNum) {
		this.regPortNum = regPortNum;
	}
	
	

}
