package cs455.overlay.transport;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

// Should have constructor TCPConnection(clientSocket) in order to create TCPSenderThread (on the socket) and 
// TCPReceiverThread (also on the socket)
// constructor should also take event factory so you can call ef.CreateEvent to return type Event (which is essentially which message to deal with)
public class TCPConnection {
	final Socket clientSock;
	final byte[] data;

	
	public TCPConnection(Socket clientSock, byte[] data) throws IOException {
		this.clientSock = clientSock;
		this.data = data;
		if(data != null) {
			TCPSender sender = new TCPSender(this.clientSock);
			sender.sendData(data);
			// create sender thread?: 
			
		}
		else {
			TCPReceiver receiver = new TCPReceiver(clientSock);
			Thread t = new Thread(receiver);
			t.start();
			
		}
	}

}


