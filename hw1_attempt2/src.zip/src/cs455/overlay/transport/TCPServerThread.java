package cs455.overlay.transport;

import java.io.IOException;

import cs455.overlay.wireformats.Event;
import cs455.overlay.wireformats.OVERLAY_NODE_SENDS_REGISTRATION;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import cs455.overlay.node.RegEntry;


// This is where you will have your serverSocket
// needs constructor to take ef (event factory)
// and create connection needs to take ef as well
public class TCPServerThread implements Runnable {
	byte msgType;
	byte localAddrLen;
	byte[] localAddr;
	int localPortNum;
	ServerSocket servSock;
	OVERLAY_NODE_SENDS_REGISTRATION newRegObj;
	
	public byte getMsgType() {
		return msgType;
	}


	public void setMsgType(byte msgType) {
		this.msgType = msgType;
	}


	public byte getLocalAddrLen() {
		return localAddrLen;
	}


	public void setLocalAddrLen(byte localAddrLen) {
		this.localAddrLen = localAddrLen;
	}


	public byte[] getLocalAddr() {
		return localAddr;
	}


	public void setLocalAddr(byte[] localAddr) {
		this.localAddr = localAddr;
	}


	public int getLocalPortNum() {
		return localPortNum;
	}


	public void setLocalPortNum(int localPortNum) {
		this.localPortNum = localPortNum;
	}


	
	public TCPServerThread (int portNumber) throws IOException {
		try {
			this.servSock = new ServerSocket(portNumber);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			int localPortNum = servSock.getLocalPort();
			InetAddress addr = servSock.getInetAddress();
			byte[] localAddr = addr.getAddress();
			byte localAddrLen = (byte) localAddr.length;
			byte msgType = 2;
			
			this.msgType = msgType;
			this.localAddrLen = localAddrLen;
			this.localAddr = localAddr;
			this.localPortNum = localPortNum;
			
			//RegEntry message = new RegEntry(OVERLAY_NODE_SENDS_REGISTRATION, localAddrLen, localAddr, localPortNum);	
			// pack this data and send to register with message type
			
			
			
			
			
			
			
			// need to create a (thread?) with ServerSocket.accept()
			
			while(true) {
				// accept all connection requests and create a new socket connection to handle request
				Socket clientSock = servSock.accept();
				
				//create a new thread to handle request with TCPConnection
				//byte[] fakeBytes = null;
				TCPConnection receiver = new TCPConnection(clientSock, null);
				
			}
			
	}
	
	
	@Override
	public void run() {

		// Create ServerSocket for listening and get information for registry: 
		try(ServerSocket servSock = new ServerSocket(0)) {
			int localPortNum = servSock.getLocalPort();
			InetAddress addr = servSock.getInetAddress();
			byte[] localAddr = addr.getAddress();
			byte localAddrLen = (byte) localAddr.length;
			byte msgType = 2;
			
			this.msgType = msgType;
			this.localAddrLen = localAddrLen;
			this.localAddr = localAddr;
			this.localPortNum = localPortNum;
			
			//RegEntry message = new RegEntry(OVERLAY_NODE_SENDS_REGISTRATION, localAddrLen, localAddr, localPortNum);	
			// pack this data and send to register with message type
			
			
			OVERLAY_NODE_SENDS_REGISTRATION newRegistrationMsg = new OVERLAY_NODE_SENDS_REGISTRATION(msgType, localAddrLen, localAddr, localPortNum);
			// send registry info 
			Socket socket = new Socket();
			TCPConnection sendRegistryInfo = new TCPConnection(socket, newRegistrationMsg.getBytes());
			
			
			
			// need to create a (thread?) with ServerSocket.accept()
			
			while(true) {
				// accept all connection requests and create a new socket connection to handle request
				Socket clientSock = servSock.accept();
				
				//create a new thread to handle request
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	

}

